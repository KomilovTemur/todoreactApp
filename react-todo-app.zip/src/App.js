 import React, { useState, useMemo } from "react";
import PostForm from "./components/PostForm";
import TableList from "./components/TableList";
// import MyInput from "./components/UI/input/MyInput";
import MySelect from "./components/UI/select/MySelect";

const App = () => {
  const [posts, setPosts] = useState([
    { id: 1, title: "JavaScript", stack: "MERN Stack" },
    { id: 2, title: "Python", stack: "Full Stack" },
    { id: 3, title: "C#", stack: "Cyber" },
    { id: 4, title: "Go Lang", stack: "Backend" },
  ]);

  const [select, setSelect] = useState("");
  const [search, setSearch] = useState("");

  const SortedPosts = useMemo(() => {
    if (select) {
      return [...posts].sort((a, b) => a[select].localeCompare(b[select]));
    }
    return posts;
  }, [select, posts]);

  const sortedAndSearchPosts = useMemo(() => {
    return SortedPosts.filter((posts) => posts.title);
  }, [search, SortedPosts]);


  const createPost = (newPost) => {
    setPosts([...posts, newPost]);
  };

  const removePost = (post) => {
    setPosts(posts.filter((s) => s.id !== post.id));
  };

  const sortPost = (sort) => {
    setSelect(sort);
  };

  return (
    <div className="app w-50 mx-auto">
      <PostForm createPost={createPost} />
      <div className="d-flex justify-content-between my-2">
        {/* <MyInput
          className="form-control"
          placeholder="Search..."
          value={search}
          onInput={(e) => setSearch(e.target.value)}
        /> */}

        <MySelect
          value={select}
          onChange={sortPost}
          defaultValue="soted by"
          options={[
            { value: "title", name: "Programming" },
            { value: "stack", name: "Jobs" },
          ]}
        />
      </div>
      {posts.length ? (
        <TableList
          remove={removePost}
          posts={SortedPosts}
          title="programming language"
        />
      ) : (
        <h6 className="my-3 text-center">you should some post</h6>
      )}
    </div>
  );
};

export default App;
