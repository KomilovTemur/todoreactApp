import React, {useState} from "react";
import MyButton from "./UI/button/MyButton";
import MyInput from "./UI/input/MyInput";


export default function PostForm({createPost}) {
  const [post, setPost] = useState({title: "", stack: ""})
  const addPost = (e) => {
    e.preventDefault();
    const newPost = {
        ...post,
        id: Date.now()
    }
    createPost(newPost)
  }
  return (
    <>
      <h4 className="text-center">Create your first post</h4>
      <form>
        <MyInput
          type="text"
          className="form-control"
          placeholder="Enter your favroirite stack"
          value={post.title}
          onChange={(e) => setPost({ ...post, title: e.target.value })}
        />
        <MyInput
          type="text"
          className="form-control my-3"
          placeholder="Enter your favroirite stack"
          value={post.stack}
          onChange={(e) => setPost({ ...post, stack: e.target.value })}
        />
        <MyButton className="btn btn-primary w-100" onClick={addPost}>
          Add post
        </MyButton>
      </form>
    </>
  );
}